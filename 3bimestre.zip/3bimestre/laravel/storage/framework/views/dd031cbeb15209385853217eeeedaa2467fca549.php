
<?php $__env->startSection('mainview'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class='col-4 mx-4'>

        <form action ="<?php echo e(url('employee/edit/'.$id)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <div class="row mb-3">
                <label for="FormControlInputName" class="form-label">Nome:</label>
                <input type="text" class="form-control" name="FormControlInputName" id="FormControlInputName" value="<?=$name?>" placeholder="<?=$name?>">
            </div>

            <div class="row mb-3">
                <label for="FormControlInputOcupation" class="form-label">Cargo:</label>
                <input type="text" class="form-control" name="FormControlInputOcupation" list="datalistOptions" id="FormControlInputOcupation" value="<?=$ocupation?>" placeholder="<?=$ocupation?>">
                <datalist id="datalistOptions">
                    <option value="Diretor">
                    <option value="Gerente">
                    <option value="Engenheiro">
                </datalist>
            </div>

            <div class="row mb-3">
                <label for="FormControlInputAdress" class="form-label">Endereço:</label>
                <input type="text" class="form-control" name="FormControlInputAdress" id="FormControlInputAdress" value="<?=$adress?>" placeholder="<?=$adress?>">
            </div>

            <div class="row mb-3">
                <label for="FormControlInputSalary" class="form-label">Salário:</label>
                <input type="text" class="form-control" name="FormControlInputSalary" id="FormControlInputSalary" value="<?=$salary?>" placeholder="<?=$salary?>">
            </div>


            <button type="submit" class="btn btn-primary">Salvar edição</button>




        </form>



    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ds1\ds1-crud\resources\views/pages/formedit.blade.php ENDPATH**/ ?>
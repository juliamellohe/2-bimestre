<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="/">Página Inicial</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link" href="/register">Registrar funcionário</a>
        </li>


      </ul>

      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
            <a class="nav-link" href="/gerente">Nº Gerentes</a>
        </li>
        <li class="nav-item">
            <a name="btEngenheiro" class="nav-link" href="/engenheiro"> Nº Engenheiros</a>
        </li>
        <li class="nav-item">
            <a name="btSalario" class="nav-link" href="/salario">Maior salário</a>
        </li>
      </ul>
    </div>
  </div>
</nav><?php /**PATH C:\ds1\ds1-crud\resources\views/includes/header.blade.php ENDPATH**/ ?>
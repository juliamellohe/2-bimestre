@extends('layout.mainview')
@section('mainview')

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


    <div class='col-4 mx-4'>

        <form action ="{{ url('employee/edit/'.$id) }}" method="post">
            @csrf

            <div class="row mb-3">
                <label for="FormControlInputName" class="form-label">Nome:</label>
                <input type="text" class="form-control" name="FormControlInputName" id="FormControlInputName" value="<?=$name?>" placeholder="<?=$name?>">
            </div>

            <div class="row mb-3">
                <label for="FormControlInputOcupation" class="form-label">Cargo:</label>
                <input type="text" class="form-control" name="FormControlInputOcupation" list="datalistOptions" id="FormControlInputOcupation" value="<?=$ocupation?>" placeholder="<?=$ocupation?>">
                <datalist id="datalistOptions">
                    <option value="Diretor">
                    <option value="Gerente">
                    <option value="Engenheiro">
                </datalist>
            </div>

            <div class="row mb-3">
                <label for="FormControlInputAdress" class="form-label">Endereço:</label>
                <input type="text" class="form-control" name="FormControlInputAdress" id="FormControlInputAdress" value="<?=$adress?>" placeholder="<?=$adress?>">
            </div>

            <div class="row mb-3">
                <label for="FormControlInputSalary" class="form-label">Salário:</label>
                <input type="text" class="form-control" name="FormControlInputSalary" id="FormControlInputSalary" value="<?=$salary?>" placeholder="<?=$salary?>">
            </div>


            <button type="submit" class="btn btn-primary">Salvar edição</button>




        </form>



    </div>

@endsection
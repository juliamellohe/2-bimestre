@extends('layout.mainview')
@section('mainview')

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


    <div class='col-4 mx-4'> <!--Igual ao utilizado no Codeigniter-->

        <form action ="/register" method="post">
            @csrf <!--Proteger o formulario-->

            <div class="row mb-3">
                <label for="FormControlInputName" class="form-label">Name:</label>
                <input type="text" class="form-control" name="FormControlInputName" id="FormControlInputName" placeholder="Nome:">
            </div>

            <div class="row mb-3">
                <label for="FormControlInputOcupation" class="form-label">Cargo:</label>
                <input type="text" class="form-control" name="FormControlInputOcupation" list="datalistOptions" id="FormControlInputOcupation" placeholder="Escolha um cargo...">
                <datalist id="datalistOptions">
                    <option value="Diretor">
                    <option value="Gerente">
                    <option value="Engenheiro">
                </datalist>
            </div>

            <div class="row mb-3">
                <label for="FormControlInputAdress" class="form-label">Address:</label>
                <input type="text" class="form-control" name="FormControlInputAdress" id="FormControlInputAdress" placeholder="Endereço:">
            </div>

            <div class="row mb-3">
                <label for="FormControlInputSalary" class="form-label">Salary:</label>
                <input type="text" class="form-control" name="FormControlInputSalary" id="FormControlInputSalary" placeholder="Salário:">
            </div>


            <button type="submit" class="btn btn-primary">Register Employee
</button>

        </form>



    </div>

@endsection

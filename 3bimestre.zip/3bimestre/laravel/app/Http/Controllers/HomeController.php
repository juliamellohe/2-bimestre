<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request; //pegando os dados do formulario
use App\Models\EmployeeModel; // product model
use Validator;

class HomeController extends Controller
{
    public function index() {
        $employeeModel = new EmployeeModel(); //product model new ProductModel()
        $data['employeeList'] = $employeeModel->all();//prega todos os dados para passar para a view //product list
        return view ('pages.formview', $data);
    }

    public function register_employee() {
        return view ('pages.formregister');
    }

    public function store_employee(Request $request) {

        $validator = $this->setValidationFields($request);

        if ($validator->fails()){
            return back()->withErrors($validator)->withInput();//ficar na mesma pagina
        }

        $employeeModel = new EmployeeModel();
        $employeeModel->name = $request->FormControlInputName; // vem do formregister
        $employeeModel->ocupation = $request->FormControlInputOcupation;
        $employeeModel->adress = $request->FormControlInputAdress;
        $employeeModel->salary = $request->FormControlInputSalary;
        $employeeModel->save(); // PARA SALVAR NO BANCO

       return redirect('/')->with('success','Successful registered employee!');
    }

    // delete update edit
    public function delete_employee($id) {
        $employeeModel = new EmployeeModel();
        $employeeModel->find($id)->delete();
        return redirect('/')->with('success', 'Employee successfully deleted!');
    }

    public function edit_employee_view($id) {
        $data_to_be_updated = EmployeeModel::where('id',$id)->first();

        return view('pages.formedit', $data_to_be_updated);
    }

    public function update_employee(Request $request, $id) {
        $validator = $this->setValidationFields($request);

        if ($validator->fails()){
            return back()->withErrors($validator)->withInput();
        }

        $data_to_be_updated = array(
            'name'=>$request->FormControlInputName,
            'ocupation'=>$request->FormControlInputOcupation,
            'adress'=>$request->FormControlInputAdress,
            'salary'=>$request->FormControlInputSalary,
        );

        EmployeeModel::find($id)->update($data_to_be_updated);
        return redirect('/')->with('success', 'Employee successfully edited!');
    }

    private function setValidationFields(Request $request) {
        $validator = Validator::make($request->all(), [
            'FormControlInputName' => 'required|min:3|max:255',
            'FormControlInputOcupation' => 'required|min:7|max:10',
            'FormControlInputAdress' => 'required|min:3|max:255',
            'FormControlInputSalary' => 'required|numeric'

        ]);
        return $validator;
    }

    // SEARCH ---------
    public function search_gerente(){
        $data['employeeList'] = EmployeeModel::where('ocupation','like','Gerente')->get();
        $gerente = 0;
        foreach ($data['employeeList'] as $item) {
            $gerente += 1;
        }
        return redirect('/')->with('inform', 'The number of managers is '.$gerente);
    }
    public function search_engenheiro(){
        $data['employeeList'] = EmployeeModel::where('ocupation','like','Engenheiro')->get();
        $engenheiro = 0;
        foreach ($data['employeeList'] as $item) {
            $engenheiro += 1;
        }
        return redirect('/')->with('inform', 'The number of managers is '.$engenheiro);
    }

    public function sorting_salary() {
        $data['employeeList'] = EmployeeModel::orderBy('salary','desc')->get();
        return view ('pages.formview', $data);
    }
    public function search_salario(){
        $salario = 0;
        $employee = "";
        $ocupatiom = "";
        $data['employeeList'] = EmployeeModel::all();
        foreach ($data['employeeList'] as $item) {
            if($item->salary > $salario) {
                $salario = $item->salary;
                $employee = $item->name;
                $ocupation = $item->ocupation;
            }
        }
        return redirect('/')->with('inform', 'The biggest salary is'.$salario.'
        belonging to '.$ocupation.' '.$employee);
    }
}

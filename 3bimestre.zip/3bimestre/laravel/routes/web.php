<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController; // refência de HomeController

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class,'index']); //chamando o welcome

Route::get('/register', [HomeController::class,'register_employee']); //register product
Route::post('/register', [HomeController::class,'store_employee']);
Route::get('/employee/delete/{id}', [HomeController::class,'delete_employee']); //delete product
Route::get('/employee/edit/{id}', [HomeController::class,'edit_employee_view']);
Route::post('/employee/edit/{id}', [HomeController::class,'update_employee']);
Route::get('/gerente', [HomeController::class,'search_gerente']);
Route::get('/engenheiro', [HomeController::class,'search_engenheiro']);
Route::get('/salario', [HomeController::class,'search_salario']);
Route::get('/sorting', [HomeController::class,'sorting_salary']);

<?php

namespace App\Controllers;

use App\Models\CarModel; //product models

class Home extends BaseController
{
	public function index() //chamado a partir do routes.php  
	{
		$carModel = new CarModel();
		$data['carList'] = $carModel->getCar(); // getProduct
		//print_r($data)
		echo view('common/header');
		echo view('form_view', $data);
		echo view('common/footnote');
	}

	public function register_car()
	{
		echo view('common/header');
		echo view('form_register');
		echo view('common/footnote');
	}

	public function store_car()
	{ //store_product

		$carModel = new CarModel();

		//set da validação
		$validation = \Config\Services::validation();

		$validation->setRules([
			'FormControlInputMarca' => ['label' => 'Marca',	'rules' => 'required', 'errors' => ['required' => 'Defina a marca do automóvel']], 'FormControlInputModelo' => ['label' => 'Modelo',	'rules' => 'required', 'errors' => ['required' => 'Defina o modelo do automóvel']], 'FormControlInputQuilometros' => ['label' => 'Ano',	'rules' => 'required|integer', 'errors' => ['required' => 'Defina a quilometragem do automóvel', 'integer' => 'Defina a quilometragem inteira, sem . ou ,']], 'FormControlInputAno' => ['label' => 'Quilometros',	'rules' => 'required|integer', 'errors' => ['required' => 'Defina o ano do automóvel', 'integer' => 'Defina um ano válido']], 'FormControlInputPreco' => ['label' => 'Preco',	'rules' => 'required|decimal', 'errors' => ['required' => 'Defina o preço do automóvel', 'decimal' => 'Defina um valor válido com . no lugar da ,']],

		]); //print_r($data);

		if ($validation->withRequest($this->request)->run()) {

			$data = array( //padrao referencia --> 'example' => $this -> request -> getVar('FormControlInputExample')
				'marca' => $this->request->getVar('FormControlInputMarca'),
				'modelo' => $this->request->getVar('FormControlInputModelo'),
				'preco' => $this->request->getVar('FormControlInputPreco'),
				'ano' => $this->request->getVar('FormControlInputAno'),
				'quilometros' => $this->request->getVar('FormControlInputQuilometros')
			);
			//productModel->insertProduct
			$carModel->InsertCar($data);
			$this->session->setFlashdata('messageRegisterOk', "Automóvel registrado com sucesso!");
			return redirect()->to('/'); //definindo o redirecionamento
		} else {
			$this->register_car();
		}
	}
	public function delete_car($id = NULL)
	{
		if ($id == null) {
			return redirect()->to('/');
		}
		$carModel = new CarModel();
		$carModel->removeCar($id);

		$this->session->setFlashdata('messageRegisterOk', "Automóvel excluido com sucesso!");
		return redirect()->to('/');
	}
}

<?php

namespace App\Models;

use CodeIgniter\Model;

class CarModel extends Model
{
    protected $table = 'vehicles'; //protected $table = 'products'; --> PADRÃO
    protected $primaryKey = 'id';
    protected $allowedFields = ['marca', 'modelo', 'preco', 'ano', 'quilometros'];

    public function insertCar($data)
    { //inserir no banco
        return $this->insert($data);
    }

    public function getCar($id = null)
    { //getProduct
        if ($id == null) {
            return $this->findAll();
        } else {
            return $this->asArray()->where(['id' => $id])->first();
        }
    }

    public function removeCar($id = null)
    { //remove product
        return $this->delete($id);
    }
}

<!-- -->
<!-- -->
<!-- -->
<!-- -->

<!-- Apresentar(caso aconteça), o erro na tela a partir da tag alert danger do bootstrap-->
<?php if (\Config\Services::validation()->getErrors()) { ?>

    <div class="alert alert-danger" role="alert">
        <?= \Config\Services::validation()->listErrors(); ?>

    </div>
<?php
}
?>

<div class="col-4 mx-4">
    <form action="/register" method="post">
        <div class="row mb-3">
            <label for="FormControlInputMarca" class="form-label">Marca:</label>
            <input type="text" class="form-control" name="FormControlInputMarca" id="FormControlInputMarca" placeholder="Insira a marca do automóvel">
        </div>

        <div class="row mb-3">
            <label for="FormControlInputModelo" class="form-label">Modelo:</label>
            <input type="text" class="form-control" name="FormControlInputModelo" id="FormControlInputModelo" placeholder="Insira o modelo do automóvel">
        </div>

        <div class="row mb-3">
            <label for="FormControlInputAno" class="form-label">Ano:</label>
            <input type="number" min="1900" class="form-control" name="FormControlInputAno" id="FormControlInputAno" placeholder="Insira o ano do automóvel">
        </div>

        <div class="row mb-3">
            <label for="FormControlInputQuilometros" class="form-label">Quilometragem:</label>
            <input type="number" min="0" class="form-control" name="FormControlInputQuilometros" id="FormControlInputQuilometros" placeholder="Insira a quilometragem do automóvel">
        </div>

        <div class="row mb-3">
            <label for="FormControlInputPreco" class="form-label">Preço:</label>
            <input type="double" class="form-control" name="FormControlInputPreco" id="FormControlInputPreco" placeholder="Insira o preço do automóvel">
        </div>


        <button type="submit" class="btn btn-primary">Registrar automóvel</button>

    </form>
</div>
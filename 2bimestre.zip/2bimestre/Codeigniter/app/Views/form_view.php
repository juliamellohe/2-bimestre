<?php
if (session()->get('messageRegisterOk')) {
?>
  <div class="alert alert-info" role="alert">

    <?php echo "<strong>" . session()->getFlashdata('messageRegisterOk') . "</strong>"; ?>

  </div>

<?php
}
?>

<table class="table">
  <thead>
    <tr>

      <th scope="col">#</th>
      <th scope="col">Marca</th>
      <th scope="col">Modelo</th>
      <th scope="col">Preço</th>
      <th scope="col">Ano</th>
      <th scope="col">Quilometragem</th>
      <th scope="col"></th>

    </tr>
  </thead>
  <tbody>

    <?php foreach ($carList as $item) : ?>
      <tr>

        <th scope="row"> <?= $item['id'] ?></th>
        <!--mostrando conteudo-->
        <td> <?= $item['marca'] ?> </td>
        <td> <?= $item['modelo'] ?> </td>
        <td> <?= $item['preco'] ?> </td>
        <td> <?= $item['ano'] ?> </td>
        <td> <?= $item['quilometros'] ?> </td>

        <td><a href="<?php echo base_url('car/delete/' . $item['id']); ?>" class="btn btn-danger" onClick='return confirmDialog();'>Deletar</a></td>


        <script>
          function confirmDialog() {
            return confirm("Tem certeza que deseja deletar este automóvel?");
          }
        </script>

      </tr>



    <?php endforeach; ?>

  </tbody>
</table>